/*
 * dis6502.h: 6502 disassembler for Atari game simulator
 *
 * Copyright 1993-1994 Eric Smith
 *
 * $Header: /home/marble/eric/vg/atari/centsim/RCS/dis6502.h,v 1.2 1994/08/12 05:23:28 eric Exp $
 */

int disasm_6502 (word addr);
